import { hashPassword, verifyPassword } from '../lib/auth'

describe('auth utils', () => {
  it('should hash and verify password correctly', () => {
    const password = 'secret123'
    const hashed = hashPassword(password)
    expect(verifyPassword(password, hashed)).toBe(true)
    expect(verifyPassword('wrong-password', hashed)).toBe(false)
  })
})
