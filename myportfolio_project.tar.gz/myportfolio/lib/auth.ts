import { randomBytes, pbkdf2Sync } from 'crypto'

/**
 * Hash a password using PBKDF2 with a random salt.
 * The result is returned as `salt:hash`.
 */
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex')
  return `${salt}:${hash}`
}

/**
 * Verify a password against a previously hashed value.
 * The hashed value must be formatted as `salt:hash`.
 */
export function verifyPassword(password: string, stored: string): boolean {
  const [salt, originalHash] = stored.split(':')
  const hash = pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex')
  return hash === originalHash
}
