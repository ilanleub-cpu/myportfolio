# MyPortfolio

A responsive web application for managing and tracking investment portfolios. Inspired by **My Stocks**, this app allows users to create multiple portfolios, record buy & sell transactions, view current portfolio values, profit/loss, and allocations by ticker and sector.

## Features

- **Authentication**: User signup and login via email/password or OAuth providers.
- **Multiple Portfolios**: Each user can create and manage multiple portfolios.
- **Transactions**: Add, edit, or delete buy and sell transactions, including ticker, date, quantity, price and fees.
- **Dashboard**: View current portfolio values, profit/loss calculations, and allocation charts (by ticker and sector). Includes historical charts (1 D, 1 W, 1 M, 1 Y) using market data.
- **Data Integration**: Placeholders are included for integrating live market prices and historical charts via a market data API. You must provide your own API key and implementation in production.
- **CSV Import/Export**: Import past transactions from CSV files and export your transaction history.
- **PDF Reports**: Generate professional PDF reports summarising portfolio performance, tables and charts (see `scripts/export_pdf.py`).
- **Alerts**: Price and percentage‑based alerts via email or browser notifications (implementation stubs provided).
- **Responsive UI**: Built with Next.js, React, TypeScript and Tailwind CSS for a clean, mobile‑first interface.

## Getting Started

### Prerequisites

- Node.js (>= 16)
- npm or yarn
- PostgreSQL database
- Python 3.x for the PDF export script

### Environment Variables

Create a `.env` file in the root folder and define the following variables (see `.env.example` for guidance):

- `DATABASE_URL` – PostgreSQL connection string.
- `NEXTAUTH_SECRET` – Secret used by NextAuth for session tokens.
- `NEXTAUTH_URL` – Base URL of your application.
- `MARKET_DATA_API_KEY` – API key for your market data provider.

### Installation

1. Install dependencies:

   ```bash
   npm install
   ```

2. Generate the Prisma client and run migrations:

   ```bash
   npx prisma generate
   npx prisma migrate dev --name init
   ```

3. Start the development server:

   ```bash
   npm run dev
   ```

Your application will be available at `http://localhost:3000`.

### CSV Import/Export

The API route `/api/csv` includes endpoints for uploading CSV files containing transactions and exporting your transaction history. CSV files should include the columns:

```
ticker,date,qty,price,fees,type,portfolioId
```

### PDF Reports

The script `scripts/export_pdf.py` can be used to generate PDF reports summarising a portfolio. It expects a JSON file containing portfolio data. Example usage:

```bash
python3 scripts/export_pdf.py --input data/portfolio.json --output reports/portfolio.pdf
```

This script uses ReportLab to create tables and charts in the PDF. You can integrate it into your API (see `/pages/api/pdf.ts`).

### Tests

Basic unit and integration tests are provided using Jest and Testing Library. Run tests with:

```bash
npm test
```

### Deployment

For deployment, the frontend can be hosted on Vercel and the backend/API on services such as Render, Railway or AWS. Ensure environment variables are configured for production. A sample `vercel.json` configuration is included for Vercel deployment. See the repository wiki for detailed deployment instructions.

## Contributing

Contributions are welcome! Please open issues or pull requests to suggest improvements or report bugs.

## License

This project is licensed under the MIT License.