import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import Link from 'next/link'

interface Transaction {
  id: string
  ticker: string
  quantity: number
  price: number
  fees: number
  type: string
  date: string
}

export default function PortfolioDetail() {
  const router = useRouter()
  const { id } = router.query
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [portfolioName, setPortfolioName] = useState('')

  useEffect(() => {
    if (!id) return
    fetch(`/api/portfolios?id=${id}`)
      .then(res => res.json())
      .then(data => {
        setPortfolioName(data.portfolio?.name ?? '')
        setTransactions(data.transactions ?? [])
      })
  }, [id])

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">{portfolioName}</h1>
      <Link href={`/portfolios/${id}/transactions/new`} className="text-blue-500 hover:underline">
        Add Transaction
      </Link>
      <table className="min-w-full mt-4 border">
        <thead>
          <tr>
            <th className="border px-2 py-1">Ticker</th>
            <th className="border px-2 py-1">Type</th>
            <th className="border px-2 py-1">Date</th>
            <th className="border px-2 py-1">Quantity</th>
            <th className="border px-2 py-1">Price</th>
            <th className="border px-2 py-1">Fees</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map(tx => (
            <tr key={tx.id}>
              <td className="border px-2 py-1">{tx.ticker}</td>
              <td className="border px-2 py-1">{tx.type}</td>
              <td className="border px-2 py-1">{new Date(tx.date).toLocaleDateString()}</td>
              <td className="border px-2 py-1">{tx.quantity}</td>
              <td className="border px-2 py-1">{tx.price}</td>
              <td className="border px-2 py-1">{tx.fees}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
