import { useState } from 'react'
import { useRouter } from 'next/router'

export default function NewTransaction() {
  const router = useRouter()
  const { id } = router.query
  const [ticker, setTicker] = useState('')
  const [type, setType] = useState('BUY')
  const [date, setDate] = useState('')
  const [quantity, setQuantity] = useState('')
  const [price, setPrice] = useState('')
  const [fees, setFees] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await fetch('/api/transactions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        portfolioId: id,
        ticker,
        type,
        date,
        quantity: parseFloat(quantity),
        price: parseFloat(price),
        fees: parseFloat(fees),
      }),
    })
    router.push(`/portfolios/${id}`)
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">New Transaction</h1>
      <form onSubmit={handleSubmit}>
        <div className="mb-2">
          <label className="block">Ticker</label>
          <input
            className="border p-2 w-full"
            value={ticker}
            onChange={e => setTicker(e.target.value)}
          />
        </div>
        <div className="mb-2">
          <label className="block">Type</label>
          <select
            className="border p-2 w-full"
            value={type}
            onChange={e => setType(e.target.value)}
          >
            <option value="BUY">BUY</option>
            <option value="SELL">SELL</option>
          </select>
        </div>
        <div className="mb-2">
          <label className="block">Date</label>
          <input
            className="border p-2 w-full"
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
          />
        </div>
        <div className="mb-2">
          <label className="block">Quantity</label>
          <input
            className="border p-2 w-full"
            type="number"
            value={quantity}
            onChange={e => setQuantity(e.target.value)}
          />
        </div>
        <div className="mb-2">
          <label className="block">Price</label>
          <input
            className="border p-2 w-full"
            type="number"
            value={price}
            onChange={e => setPrice(e.target.value)}
          />
        </div>
        <div className="mb-2">
          <label className="block">Fees</label>
          <input
            className="border p-2 w-full"
            type="number"
            value={fees}
            onChange={e => setFees(e.target.value)}
          />
        </div>
        <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          Add
        </button>
      </form>
    </div>
  )
}
