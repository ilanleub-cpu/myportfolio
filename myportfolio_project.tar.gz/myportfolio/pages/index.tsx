import { useEffect, useState } from 'react'
import Link from 'next/link'

interface Portfolio {
  id: string
  name: string
}

export default function Home() {
  const [portfolios, setPortfolios] = useState<Portfolio[]>([])

  useEffect(() => {
    fetch('/api/portfolios')
      .then(res => res.json())
      .then(data => setPortfolios(data.portfolios ?? []))
  }, [])

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">My Portfolio Dashboard</h1>
      <Link href="/portfolios/new" className="text-blue-500 hover:underline">
        Create Portfolio
      </Link>
      <ul className="mt-4">
        {portfolios.map(p => (
          <li key={p.id} className="mb-2">
            <Link href={`/portfolios/${p.id}`} className="text-blue-500 hover:underline">
              {p.name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}
