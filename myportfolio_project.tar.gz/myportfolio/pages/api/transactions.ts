import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../lib/prisma'

/**
 * Transactions API endpoint.
 *
 * POST /api/transactions – create a new transaction.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { portfolioId, ticker, type, date, quantity, price, fees } = req.body as {
      portfolioId: string
      ticker: string
      type: 'BUY' | 'SELL'
      date: string
      quantity: number
      price: number
      fees: number
    }
    if (!portfolioId || !ticker || !type || !date) {
      return res.status(400).json({ error: 'Missing transaction fields' })
    }
    const transaction = await prisma.transaction.create({
      data: {
        portfolioId,
        ticker,
        type,
        date: new Date(date),
        quantity,
        price,
        fees,
      },
    })
    return res.status(200).json({ transaction })
  }

  return res.status(405).json({ error: 'Method not allowed' })
}
