import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../lib/prisma'
import { hashPassword, verifyPassword } from '../../lib/auth'

/**
 * Authentication API endpoint.
 *
 * Supported actions:
 * - signup: create a new user with email and password.
 * - login: verify an existing user and return user data.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { email, password, action } = req.body as {
    email: string
    password: string
    action: 'signup' | 'login'
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' })
  }
  if (!email || !password) {
    return res.status(400).json({ error: 'Missing credentials' })
  }

  if (action === 'signup') {
    // Check if user already exists
    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) {
      return res.status(400).json({ error: 'User already exists' })
    }
    const hashed = hashPassword(password)
    const user = await prisma.user.create({
      data: {
        email,
        password: hashed,
      },
    })
    return res.status(200).json({ user })
  }

  if (action === 'login') {
    const user = await prisma.user.findUnique({ where: { email } })
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' })
    }
    const valid = verifyPassword(password, user.password)
    if (!valid) {
      return res.status(401).json({ error: 'Invalid credentials' })
    }
    // In a real application you'd set a session cookie or return a JWT here.
    return res.status(200).json({ user })
  }

  return res.status(400).json({ error: 'Unknown action' })
}
