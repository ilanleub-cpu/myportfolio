import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../lib/prisma'
import { execFile } from 'child_process'
import fs from 'fs'
import os from 'os'
import path from 'path'

/**
 * PDF export API.
 *
 * GET /api/pdf?id=portfolioId – generate a PDF report for the given portfolio.
 * Calls the Python script `scripts/export_pdf.py` with a temporary JSON file
 * containing the portfolio and its transactions. The generated PDF is
 * returned as a binary response.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query
  if (!id || typeof id !== 'string') {
    return res.status(400).json({ error: 'Missing portfolio id' })
  }
  // Fetch portfolio and transactions
  const portfolio = await prisma.portfolio.findUnique({ where: { id } })
  const transactions = await prisma.transaction.findMany({ where: { portfolioId: id } })
  if (!portfolio) {
    return res.status(404).json({ error: 'Portfolio not found' })
  }
  // Prepare data for PDF
  const data = { portfolio, transactions }
  const tmpDir = os.tmpdir()
  const jsonPath = path.join(tmpDir, `${id}.json`)
  const pdfPath = path.join(tmpDir, `${id}.pdf`)
  fs.writeFileSync(jsonPath, JSON.stringify(data))
  // Determine script path relative to project root
  const scriptPath = path.join(process.cwd(), 'scripts', 'export_pdf.py')
  // Call Python script
  execFile('python3', [scriptPath, '--input', jsonPath, '--output', pdfPath], err => {
    if (err) {
      console.error(err)
      return res.status(500).json({ error: 'Failed to generate PDF' })
    }
    const pdf = fs.readFileSync(pdfPath)
    res.setHeader('Content-Type', 'application/pdf')
    res.setHeader('Content-Disposition', `attachment; filename=${id}.pdf`)
    res.status(200).send(pdf)
  })
}
