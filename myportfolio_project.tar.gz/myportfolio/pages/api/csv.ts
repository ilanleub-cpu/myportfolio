import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../lib/prisma'

// Disable the default body parser to handle raw CSV data
export const config = {
  api: {
    bodyParser: false,
  },
}

/**
 * CSV import/export API.
 *
 * POST /api/csv – import transactions from raw CSV text. CSV lines must be
 *                 formatted as: ticker,date,qty,price,fees,type,portfolioId
 * GET  /api/csv – export all transactions as a CSV file.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    let csv = ''
    req.on('data', chunk => {
      csv += chunk
    })
    req.on('end', async () => {
      const lines = csv.trim().split('\n')
      const [header, ...rows] = lines
      for (const row of rows) {
        if (!row) continue
        const [ticker, date, qty, price, fees, type, portfolioId] = row.split(',')
        await prisma.transaction.create({
          data: {
            portfolioId,
            ticker,
            date: new Date(date),
            quantity: parseFloat(qty),
            price: parseFloat(price),
            fees: parseFloat(fees),
            type: type as any,
          },
        })
      }
      return res.status(200).json({ message: 'Import completed' })
    })
    return
  }

  if (req.method === 'GET') {
    const transactions = await prisma.transaction.findMany()
    const header = 'portfolioId,ticker,date,quantity,price,fees,type'
    const rows = transactions.map(tx => {
      return `${tx.portfolioId},${tx.ticker},${tx.date.toISOString()},${tx.quantity},${tx.price},${tx.fees},${tx.type}`
    })
    const out = [header, ...rows].join('\n')
    res.setHeader('Content-Type', 'text/csv')
    res.setHeader('Content-Disposition', 'attachment;filename=transactions.csv')
    res.status(200).send(out)
    return
  }

  return res.status(405).json({ error: 'Method not allowed' })
}
