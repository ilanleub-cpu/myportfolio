import type { NextApiRequest, NextApiResponse } from 'next'
import { prisma } from '../../lib/prisma'

/**
 * Portfolios API endpoint.
 *
 * GET /api/portfolios          – list all portfolios.
 * GET /api/portfolios?id=...   – fetch a specific portfolio and its transactions.
 * POST /api/portfolios         – create a new portfolio.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    const { id } = req.query
    if (id) {
      const portfolio = await prisma.portfolio.findUnique({
        where: { id: String(id) },
      })
      const transactions = await prisma.transaction.findMany({
        where: { portfolioId: String(id) },
        orderBy: { date: 'desc' },
      })
      return res.status(200).json({ portfolio, transactions })
    }
    const portfolios = await prisma.portfolio.findMany()
    return res.status(200).json({ portfolios })
  }

  if (req.method === 'POST') {
    const { name, userId } = req.body as { name: string; userId?: string }
    if (!name) {
      return res.status(400).json({ error: 'Missing portfolio name' })
    }
    // In a real application you would derive userId from the authenticated session.
    const portfolio = await prisma.portfolio.create({
      data: {
        name,
        userId: userId ?? 'demo-user-id',
      },
    })
    return res.status(200).json({ portfolio })
  }

  return res.status(405).json({ error: 'Method not allowed' })
}
