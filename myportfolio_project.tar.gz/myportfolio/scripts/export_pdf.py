#!/usr/bin/env python3
"""
Generate a PDF report for a portfolio.

This script reads a JSON file containing a portfolio and its transactions and
outputs a formatted PDF. The JSON should have the structure:

{
    "portfolio": { "id": ..., "name": ..., "userId": ... },
    "transactions": [
        { "id": ..., "ticker": ..., "type": ..., "date": ..., "quantity": ..., "price": ..., "fees": ... },
        ...
    ]
}

Usage:
    python3 export_pdf.py --input path/to/data.json --output path/to/report.pdf

This script uses ReportLab to build a PDF document containing a title and a
table of transactions. It can easily be extended to include charts and
additional analysis.
"""
import argparse
import json
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

def generate_pdf(data: dict, output_path: str) -> None:
    """Generate a PDF report from portfolio data."""
    doc = SimpleDocTemplate(output_path, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    portfolio = data.get('portfolio', {})
    transactions = data.get('transactions', [])

    # Title
    title = f"Portfolio Report: {portfolio.get('name', 'Untitled')}"
    story.append(Paragraph(title, styles['Title']))
    story.append(Spacer(1, 12))

    # Table data
    table_data = [['Ticker', 'Type', 'Date', 'Quantity', 'Price', 'Fees']]
    for tx in transactions:
        table_data.append([
            tx.get('ticker', ''),
            tx.get('type', ''),
            str(tx.get('date', ''))[:10],
            str(tx.get('quantity', '')),
            str(tx.get('price', '')),
            str(tx.get('fees', '')),
        ])

    table = Table(table_data, repeatRows=1)
    table_style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ])
    table.setStyle(table_style)
    story.append(table)

    doc.build(story)

def main():
    parser = argparse.ArgumentParser(description='Create a portfolio PDF report.')
    parser.add_argument('--input', required=True, help='Path to JSON input file')
    parser.add_argument('--output', required=True, help='Path to PDF output file')
    args = parser.parse_args()
    with open(args.input, 'r') as f:
        data = json.load(f)
    generate_pdf(data, args.output)

if __name__ == '__main__':
    main()
